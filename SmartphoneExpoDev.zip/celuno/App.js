import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, ScrollView,ImageBackground, Linking, Button, TextInput, FlatList} from 'react-native';
import { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import * as ImagePicker from 'expo-image-picker';
import { Picker } from '@react-native-picker/picker';
import * as MediaLibrary from 'expo-media-library';
function HomeScreen({ navigation }) {
    return (
       <ImageBackground
      source={{ uri: "https://imgs.search.brave.com/WELv5fq3PtKHKzzfXe6nWHWrLo2zl1Ip8BRb87g0bP0/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMtd2l4bXAtZWQz/MGE4NmI4YzRjYTg4/Nzc3MzU5NGMyLndp/eG1wLmNvbS9mLzc2/NmYxN2NiLWNjODQt/NDI2My1hZjExLWMy/NDE1Zjk4ZDFhOC9k/ZGd3NmRjLWI3NDJm/NzkyLTZiZTAtNGIy/Yi1hNmUzLTRiZjVl/YmEzMjhiNC5qcGc_/dG9rZW49ZXlKMGVY/QWlPaUpLVjFRaUxD/SmhiR2NpT2lKSVV6/STFOaUo5LmV5Snpk/V0lpT2lKMWNtNDZZ/WEJ3T2pkbE1HUXhP/RGc1T0RJeU5qUXpO/ek5oTldZd1pEUXhO/V1ZoTUdReU5tVXdJ/aXdpYVhOeklqb2lk/WEp1T21Gd2NEbzNa/VEJrTVRnNE9UZ3lN/alkwTXpjellUVm1N/R1EwTVRWbFlUQmtN/alpsTUNJc0ltOWlh/aUk2VzF0N0luQmhk/R2dpT2lKY0wyWmNM/emMyTm1ZeE4yTmlM/V05qT0RRdE5ESTJN/eTFoWmpFeExXTXlO/REUxWmprNFpERmhP/Rnd2WkdSbmR6WmtZ/eTFpTnpReVpqYzVN/aTAyWW1Vd0xUUmlN/bUl0WVRabE15MDBZ/bVkxWldKaE16STRZ/alF1YW5CbkluMWRY/U3dpWVhWa0lqcGJJ/blZ5YmpwelpYSjJh/V05sT21acGJHVXVa/RzkzYm14dllXUWlY/WDAuaTVwWmtSSGhY/ZkpkWVhncXJ6T1Qz/WDVSaDVkekxEWHhC/d2xWT2ZvUVA2WQ" }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.container}>
        <Text style={styles.time}>07:30</Text>
        <Text style={styles.date}>Lunes, 25 de Febrero</Text>
        <Text> </Text>
        <Text> </Text>
        <Text> </Text>
        <Text> </Text>
        <Text> </Text>
        <Text> </Text>

        <View style={styles.itemContainer}>
            <TouchableOpacity onPress={() => navigation.navigate('Inicio')}>
                <Image
                    source={{
                        uri: 'https://www.pngarts.com/files/17/Fingerprint-PNG-Photo-HQ.png',
                    }}
                    style={styles.scrollImage}/>
            </TouchableOpacity>
        </View>

        <Text style={styles.instruction}>Ingresa tu huella para desbloquear</Text>
      </View>
    </ImageBackground>
  );
}



function FutbolScreen({ navigation }) {
    return (
      <ScrollView>
      <View style={styles.contenedor}>


      <View style={styles.baseText,styles.titleText}>
           <Text style={styles.instruction}> 7:30 pm </Text>
      </View>

      <View style={styles.baseText,styles.titleText2}>
          <Text style={styles.instruction}> Lun, 25 de Febrero </Text>
      </View>

      <View >
          <Image source={{uri:'https://png.pngtree.com/png-vector/20220517/ourmid/pngtree-google-search-bar-classic-window-png-image_4643242.png'}}
              style= {{ width: 300, height: 180, resizeMode: 'contain' }}/>
      </View>
              <View style={styles.row}>
                  <View style={styles.Contenedor1}>
                    <TouchableOpacity onPress={() => Linking.openURL('https://photos.google.com/u/0/albums?hl=es&pli=1')}>
                      <Image source={{uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAWTNMXzPs_8hx82WpUfwIvws4HIw2lhZxug&s'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
                 

                  <View style={styles.Contenedor2}>
                    <TouchableOpacity onPress={() => Linking.openURL('https://play.google.com/store/games?hl=es_MX')}>
                      <Image source={{uri: 'https://static.vecteezy.com/system/resources/previews/022/484/501/non_2x/google-play-store-icon-logo-symbol-free-png.png'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
                  
                  <View style={styles.Contenedor3}>
                    <TouchableOpacity onPress={() => Linking.openURL('mailto:EMAIL')}>
                      <Image source={{uri: 'https://static.vecteezy.com/system/resources/previews/016/716/465/non_2x/gmail-icon-free-png.png'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>

                  <View style={styles.Contenedor4}>
                     <TouchableOpacity onPress={() => Linking.openURL('https://classroom.google.com/')}>
                      <Image source={{uri: 'https://as2.ftcdn.net/v2/jpg/03/56/03/45/500_F_356034511_pA6jdW0tUMxgscosCSboGSrW1W7ydFmJ.jpg'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
               
            </View>

            

             <View style={styles.row}>
                  <View style={styles.Contenedor1}>
                    <TouchableOpacity onPress={() => Linking.openURL('https://open.spotify.com/intl-es')}>
                      <Image source={{uri: 'https://cdn.pixabay.com/photo/2016/10/22/00/15/spotify-1759471_640.jpg'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>

                  <View style={styles.Contenedor2}>
                     <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com/')}>
                      <Image source={{uri: 'https://cdn-icons-png.flaticon.com/256/124/124010.png'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
                  
                  
                  <View style={styles.Contenedor3}>
                    <TouchableOpacity onPress={() => Linking.openURL('https://www.instagram.com/')}>
                      <Image source={{uri: 'https://imgs.search.brave.com/fjZdjSzeDiivhbeluY4eKKczLy63fp3piHBZ_wSlz0U/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90NC5m/dGNkbi5uZXQvanBn/LzA2Lzk1LzgyLzMz/LzM2MF9GXzY5NTgy/MzM5NF90MGxkODJ3/d3A3bk9FMk5pTzdN/RzBYaXcwMHY0T05n/Ry5qcGc'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
                  
                  <View style={styles.Contenedor4}>
                    <TouchableOpacity onPress={() => navigation.navigate('Mensaje')}>
                      <Image source={{uri: 'https://thumbs.dreamstime.com/b/icono-de-whatsapp-blanco-y-verde-los-medios-sociales-forma-iluminaci%C3%B3n-blanca-251223623.jpg'}} style={styles.scrollImage2} />
                    </TouchableOpacity>>
                  </View>
                </View>
                

              <View style={styles.row}>
                  <View style={styles.Contenedor1}>
                      <TouchableOpacity onPress={() => navigation.navigate('chat')}>
                      <Image source={{uri: 'https://media.istockphoto.com/id/828430032/es/vector/icono-de-libro-blanco-nube-hablar-por-chat.jpg?s=170667a&w=0&k=20&c=f7o3lIRcQT84elDGeczZpidOOVmj5sA7yNn-B6ncB9k='}} style={styles.scrollImage2} />
                    </TouchableOpacity>>
                  </View>

                  <View style={styles.Contenedor2}>
                     <TouchableOpacity onPress={() => navigation.navigate('Juego')}>
                      <Image source={{uri: 'https://img.freepik.com/vector-premium/icono-joystick-gamepad-pixeles-8-bits-activos-juegos-ilustracion-vectorial_614713-242.jpg'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>
                  
                  <View style={styles.Contenedor3}>
                     <TouchableOpacity onPress={() => Linking.openURL('https://www.youtube.com/')}>
                      <Image source={{uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvuShuFaR8lL1Ay-l6R5tcBhCalU55J-hrIQ&s'}} style={styles.scrollImage2} />
                    </TouchableOpacity>
                  </View>


                  <View style={styles.Contenedor4}>
                     <TouchableOpacity onPress={() => Linking.openURL('https://www.google.com.mx/maps/preview')}>
                        <Image source={{uri: 'https://e7.pngegg.com/pngimages/172/480/png-clipart-google-maps-apple-maps-location-summer-jam-logo-sign-thumbnail.png'}} style={styles.scrollImage2} />
                      </TouchableOpacity>``
                  </View>
               </View>

               <View style={styles.row}>
                  <View style={styles.Contenedor1}>
                     <TouchableOpacity onPress={() => navigation.navigate('Llamada')}>
                <Image
                    source={{
                        uri: 'https://e7.pngegg.com/pngimages/668/335/png-clipart-telephone-computer-icons-vektor-miscellaneous-blue-thumbnail.png',
                    }}
                    style={styles.scrollImage2}/>
            </TouchableOpacity>
                  </View>

                  <View style={styles.Contenedor2}>
                       <TouchableOpacity onPress={() => navigation.navigate('camara')}>
                <Image
                    source={{
                        uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7z4Q-PlxHFEtEFBq45uFmq7YlGLgTtta__g&s',
                    }}
                    style={styles.scrollImage2}/>
            </TouchableOpacity>
                  </View>
                  
                  <View style={styles.Contenedor3}>
                <TouchableOpacity onPress={() => navigation.navigate('Ecuacion')}>
                <Image
                    source={{
                        uri: 'https://w7.pngwing.com/pngs/793/209/png-transparent-quadratic-equation-virtual-currency-electroneum-initial-coin-offering-quadratic-angle-investment-logo.png',
                    }}
                    style={styles.scrollImage4}/>
            </TouchableOpacity>
                  </View>

                  <View style={styles.Contenedor4}>
                  <TouchableOpacity onPress={() => navigation.navigate('Calculadora')}>
                <Image
                    source={{
                        uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNStbfjEVn4dXoTqF1wQmTpvjr3ZMO13poOg&s',
                    }}
                    style={styles.scrollImage4}/>
            </TouchableOpacity>
                  </View>
               </View>
          </View>
          </ScrollView>
  );
}


function LlamadaScreen() {
  const tel1 = () => {
    Linking.openURL('tel:2222515142');
  };
  const tel2 = () => {
    Linking.openURL('tel:2213593408');
  };
  const tel3 = () => {
    Linking.openURL('tel:2215856905');
  };
 const [number, onChangeNumber] = React.useState('');
   const telLibre = () => {
    Linking.openURL(`tel:${number}`);
  };





  return (
    <View style={styles.outerContainer}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
     <View style={styles.navBar}>
      <TouchableOpacity onPress={telLibre} style={styles.navItem}>
        <Image
          source={{
            uri: 'https://images.vexels.com/media/users/3/205069/isolated/preview/f207045d96c258fed664305f0ac2c5bd-icono-de-auricular-de-telefono-azul.png',
          }}
          style={styles.icon}
        />

        
      </TouchableOpacity>
      <TextInput
          style={styles.input}
          onChangeText={onChangeNumber}
          placeholder="Llamada telefonica"
          value={number}
          keyboardType="numeric"
        />
      

    </View>
        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://imgs.search.brave.com/ylXVJ9Jqo7PErBNIFe2H01O0GEU4r9uFDTYcPG9saWw/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93d3cu/ZmFtb3VzYmlydGhk/YXlzLmNvbS9mYWNl/cy92ZWdldHRhNzc3/LWltYWdlLmpwZw',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Ariel Cruz</Text>
          <Text style={styles.cardText}>Consorcio</Text>
          <TouchableOpacity onPress={tel1}>
                <Image
                    source={{
                        uri: 'https://c0.klipartz.com/pngpicture/759/922/gratis-png-logo-del-telefono-iphone-telefono-smartphone-telefono.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
        </View>

        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAif8utL3VYjFQysowmrWqo-Aq_Szqo-pI1g&s',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Valeria Marin</Text>
          <Text style={styles.cardText}>Bosques</Text>
               <TouchableOpacity onPress={tel2}>
                <Image
                    source={{
                        uri: 'https://c0.klipartz.com/pngpicture/759/922/gratis-png-logo-del-telefono-iphone-telefono-smartphone-telefono.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
        </View>

        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://preview.redd.it/6cts5sv00wk61.jpg?width=640&crop=smart&auto=webp&s=4c60dcd802ac53a0f2d2843dc66008d4945af572',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Farid Isai</Text>
          <Text style={styles.cardText}>Mayorazgo</Text>
           <TouchableOpacity onPress={tel3}>
                <Image
                    source={{
                        uri: 'https://c0.klipartz.com/pngpicture/759/922/gratis-png-logo-del-telefono-iphone-telefono-smartphone-telefono.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
            
        </View>

         <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://i.pinimg.com/736x/53/75/8c/53758cb1b8f1ac7758da786425f390ef.jpg',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Lester Crest</Text>
          <Text style={styles.cardText}>Los Santos</Text>
           <TouchableOpacity onPress={tel1}>
                <Image
                    source={{
                        uri: 'https://c0.klipartz.com/pngpicture/759/922/gratis-png-logo-del-telefono-iphone-telefono-smartphone-telefono.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
            
        </View>
      </ScrollView>
    </View>
  );
}

function CalculadoraScreen() {
  const [input, setInput] = useState("");


  const handlePress = (btn) => {
    if (btn === "=") {
      try {
        setInput(eval(input).toString());
      } catch {
        setInput("Error");
      }
    } else if (btn === "C") {
      setInput("");
    } else if (btn === "x²") {
      setInput((parseFloat(input) ** 2));
    } else if (btn === "√") {
      setInput((Math.sqrt(parseFloat(input))));
    } else if (btn === "+/-") {
      setInput((parseFloat(input) * -1));
    } else if (btn === "π") {
      setInput(3.1416)
    } else {
      setInput(input + btn);
    }
  };
 return (
  <View style={styles.contenedorGeneral}>
    <TextInput
      style={styles.entradaTexto}
      placeholder="0"
      value={input}
      editable={false}
    />

    <View style={styles.fila}>
      <View style={styles.botonContenedor}>
        <Button title="π" color="#424949" onPress={() => handlePress("π")} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="CE" color="#424949" onPress={() => setInput("")} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="C" color="#424949" onPress={() => handlePress("C")} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="⌫" color="#424949" onPress={() => setInput(input.slice(0, -1))} />
      </View>
    </View>

    <View style={styles.fila}>
      <View style={styles.botonContenedor}>
        <Button title="1/x" color="#424949" onPress={() => setInput((1 / parseFloat(input)).toString())} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="x²" color="#424949" onPress={() => handlePress("x²")} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="√" color="#424949" onPress={() => handlePress("√")} />
      </View>
      <View style={styles.botonContenedor}>
        <Button title="÷" color="#424949" onPress={() => handlePress("/")} />
      </View>
    </View>

    <View style={styles.fila}>
      {["7", "8", "9", "*"].map((btn) => (
        <View style={styles.botonContenedor} key={btn}>
          <Button title={btn} color="#424949" onPress={() => handlePress(btn)} />
        </View>
      ))}
    </View>

    <View style={styles.fila}>
      {["4", "5", "6", "-"].map((btn) => (
        <View style={styles.botonContenedor} key={btn}>
          <Button title={btn} color="#424949" onPress={() => handlePress(btn)} />
        </View>
      ))}
    </View>

    <View style={styles.fila}>
      {["1", "2", "3", "+"].map((btn) => (
        <View style={styles.botonContenedor} key={btn}>
          <Button title={btn} color="#424949" onPress={() => handlePress(btn)} />
        </View>
      ))}
    </View>

    <View style={styles.fila}>
      {["+/-", "0", "."].map((btn) => (
        <View style={styles.botonContenedor} key={btn}>
          <Button title={btn} color="#424949" onPress={() => handlePress(btn)} />
        </View>
      ))}
      <View style={styles.botonIgualContenedor}>
        <Button title="=" color="#900cc2" onPress={() => handlePress("=")} />
      </View>
    </View>
  </View>
);

}

function Resolverecuacion({ navigation }) {
  const [numeroA, setnumA] = useState('');
  const [numeroB, setnumB] = useState('');
  const [numeroC, setnumC] = useState('');
  const [raiz, setRaiz] = useState('');
  const [x1, setX1] = useState('');
  const [x2, setX2] = useState('');
  const [errorEcuacion, setErrorEcuacion] = useState('');

  const calcularEcuacion = () => {
    const a = parseFloat(numeroA);
    const b = parseFloat(numeroB);
    const c = parseFloat(numeroC);

    if (a !== 0) {
      const interiorRaiz = b * b - 4 * a * c;
      setRaiz(interiorRaiz);

      if (interiorRaiz >= 0) {
        const raiz = Math.sqrt(interiorRaiz);
        const solucion1 = (-b + raiz) / (2 * a);
        const solucion2 = (-b - raiz) / (2 * a);
        setX1(solucion1);
        setX2(solucion2);
        setErrorEcuacion('');
      } else {
        setErrorEcuacion('La raíz es compleja.');
        setX1('');
        setX2('');
      }
    } else {
      setErrorEcuacion('Error, división por cero.');
      setRaiz('');
      setX1('');
      setX2('');
    }
  };

  const reiniciar = () => {
    setnumA('');
    setnumB('');
    setnumC('');
    setRaiz('');
    setX1('');
    setX2('');
    setErrorEcuacion('');
  };

  return (
    <ScrollView style={styles.container8}>
      <View style={styles.header2}>
        <Image
          source={{
            uri: 'https://recursos.pacoelchato.com/img/1T7az4LjKZyNDvmIE9D9gZEbVUA5Z9Yh7lh0ZkSp.gif',
          }}
          style={styles.headerImage2}
        />
      </View>

      <Text style={styles.title}>Ingrese los datos</Text>

      <TextInput
        style={styles.input1}
        placeholder="a"
        keyboardType="numeric"
        value={numeroA}
        onChangeText={setnumA}
      />
      <TextInput
        style={styles.input1}
        placeholder="b"
        keyboardType="numeric"
        value={numeroB}
        onChangeText={setnumB}
      />
      <TextInput
        style={styles.input1}
        placeholder="c"
        keyboardType="numeric"
        value={numeroC}
        onChangeText={setnumC}
      />

      <Button title="Resolver" color="#3e5b64" onPress={calcularEcuacion} />
      <Button title="Reiniciar" color="#3e5b64" onPress={reiniciar} />
      <Button
        title="Menú Inicio"
        color="#3e5b64"
        onPress={() => navigation.navigate('Inicio')}
      />

      <Text style={styles.titlefutbol}>
        {errorEcuacion ||
          `X1: ${x1}\nX2: ${x2}`}
      </Text>
    </ScrollView>
  );
}

function juegoScreen({ navigation }) {
  const [numeroRandom, setRandom] = useState(null); 
  const [numeroUsuario, setNumeroUsuario] = useState('');
  const [mensaje, setMensaje] = useState('');

 
  const generateRandomNumber = () => {
    const randomNumber = Math.floor(Math.random() * (10 - 1 + 1)) + 1;
    setRandom(randomNumber);
  };


  const verificarNumero = () => {
    const numero = parseInt(numeroUsuario);
    
    if (numero >= 0 && numero <= 10){
        if (numero === numeroRandom ) {
            setMensaje('¡Ganaste! El número es correcto.');
        }
        else {
            setMensaje('Perdiste. Intenta nuevamente.');
            setNumeroUsuario('');
         }
    }
    else{
      setMensaje('solo numeros entre 1 y 10')
      setNumeroUsuario('');
    }
  };

  return (
    <ScrollView style={styles.container5}>
      <View style={styles.header1}>
        <Text style={styles.title}>Ingresa un número entre 1 y 10</Text>
        <Image
          source={{
            uri: 'https://i.gifer.com/origin/9f/9f90c58ff4b9f3ed1adff97e43416056.gif',
          }}
          style={styles.headerImage2}
        />
      </View>

      <View style={styles.container2}>
        <TextInput
          style={styles.input1}
          placeholder="0"
          placeholderTextColor="white"
          keyboardType="numeric"
          value={numeroUsuario}
          onChangeText={setNumeroUsuario}
        />
      </View>

      <Button
        title="Generar Número"
        color="#402650"
        onPress={generateRandomNumber}
      />

      <Button
        title="Adivinar"
        color="#402650"
        onPress={verificarNumero} 
      />

      {mensaje && <Text style={styles.title14}>{mensaje}</Text>} 

      <Button
        title="Inicio"
        color="#402650"
        onPress={() => navigation.navigate('Inicio')} 
      />
    </ScrollView>
  );
}

const ChatScreen = ({ navigation }) => {
  const [messages, setMessages] = useState([
    { id: "1", sender: "Ariel", text: "Hola" },
  ]);
  const [newMessage, setNewMessage] = useState("");

  const sendMessage = () => {
    if (newMessage.trim() !== "") {
      setMessages([
        ...messages,
        { id: (messages.length + 1).toString(), sender: "Tú", text: newMessage },
      ]);
      setNewMessage("");
    }
    if (newMessage === "Hola Ariel como estas?") {
      const response = { id: (messages.length + 2).toString(), sender: "Ariel", text: "Bien y tu?" };
      setMessages((prevMessages) => [...prevMessages, response]);
    }
    if (newMessage === "Puedes hacerme un favor?") {
      const response = { id: (messages.length + 2).toString(), sender: "Ariel", text: "Dime amigo" };
      setMessages((prevMessages) => [...prevMessages, response]);
    }
    if (newMessage === "Podrias prestarme tu XBOX?") {
      const response = { id: (messages.length + 2).toString(), sender: "Ariel", text: "Claro, pasa por el a mi casa" };
      setMessages((prevMessages) => [...prevMessages, response]);
    }
    if (newMessage === "Gracias") {
      const response = { id: (messages.length + 2).toString(), sender: "Ariel", text: "De nada" };
      setMessages((prevMessages) => [...prevMessages, response]);
    }
  };

  return (
    <View style={styles.mainContainer}>
      {}
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTHgvSGDiC7pJCCOhatzh4fx8-AJO-AXbQXg&s' }} 
          style={styles.profileImage}
        />
        <Text style={styles.headerText}>Ariel UTP </Text>
     
        
      </View>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.messageBox, item.sender === "Tú" ? styles.userMessage : styles.friendMessage]}>
            <Text style={styles.messageSender}>{item.sender}:</Text>
            <Text style={styles.messageContent}>{item.text}</Text>
          </View>
        )}
      />
      <View style={styles.inputBox}>
        <TextInput
          style={styles.inputField}
          placeholder="Escribe un mensaje..."
          value={newMessage}
          onChangeText={setNewMessage}
        />
        
         <TouchableOpacity onPress={sendMessage}>
          <Image 
            source={{ uri: 'https://preview.redd.it/w39kucuqzvwc1.jpeg?auto=webp&s=17d5b0045bf1ef7db06650252662f156ea4056f2' }} 
            style={styles.sendButtonImage}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

function CamaraScreen({ navigation }) {
const openCamera = async () => {
      // Pedir permiso para acceder a la galería
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permiso Denegado', 'Se necesita acceso a la galería para guardar la imagen.');
        return;
      }

      // Abrir la cámara
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 1,
      });

      if (!result.canceled) {
        console.log('Imagen Capturada:', result.assets[0].uri);

        try {
          // Guardar la imagen en la galería
          const asset = await MediaLibrary.createAssetAsync(result.assets[0].uri);
          console.log('Imagen guardada en la galería:', asset.uri);
          Alert.alert('Éxito', 'Imagen guardada en la galería.');
        } catch (error) {
          console.error('Error al guardar la imagen:', error);
          Alert.alert('Error', 'No se pudo guardar la imagen.');
        }
      }
    };

  return (
   <View style={styles.container}>
      <Button title="Abrir Cámara" onPress={openCamera} />
    </View>
  );
}

const SendMessageScreen = () => {
 const tel1 = () => {
    Linking.openURL('sms:2222515142');
  };
  const tel2 = () => {
    Linking.openURL('sms:2213593408');
  };
  const tel3 = () => {
    Linking.openURL('sms:2213559349');
  };
 const [number, onChangeNumber] = React.useState('');
   const telLibre = () => {
    Linking.openURL(`sms:${number}`);
  };





  return (
    <View style={styles.outerContainer}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
     <View style={styles.navBar}>
      <TouchableOpacity onPress={telLibre} style={styles.navItem}>
        <Image
          source={{
            uri: 'https://e7.pngegg.com/pngimages/997/984/png-clipart-call-icon-log-o-whatsapp-computer-icons-android-chatbot-user-whats-logo-grass.png',
          }}
          style={styles.icon}
        />
           
      </TouchableOpacity>
      <TextInput
          style={styles.input}
          onChangeText={onChangeNumber}
          placeholder="Numero nuevo whats"
          value={number}
          keyboardType="numeric"
        />
      
      </View>

        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://imgs.search.brave.com/ylXVJ9Jqo7PErBNIFe2H01O0GEU4r9uFDTYcPG9saWw/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93d3cu/ZmFtb3VzYmlydGhk/YXlzLmNvbS9mYWNl/cy92ZWdldHRhNzc3/LWltYWdlLmpwZw',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Ariel Cruz</Text>
          <Text style={styles.cardText}>Whats</Text>
          <TouchableOpacity onPress={tel1}>
                <Image
                    source={{
                        uri: 'https://e7.pngegg.com/pngimages/997/984/png-clipart-call-icon-log-o-whatsapp-computer-icons-android-chatbot-user-whats-logo-grass.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
        </View>

        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAif8utL3VYjFQysowmrWqo-Aq_Szqo-pI1g&s',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Valeria Marin</Text>
          <Text style={styles.cardText}>Whats</Text>
               <TouchableOpacity onPress={tel2}>
                <Image
                    source={{
                        uri: 'https://e7.pngegg.com/pngimages/997/984/png-clipart-call-icon-log-o-whatsapp-computer-icons-android-chatbot-user-whats-logo-grass.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
        </View>

        <View style={styles.cardContainer}>
          <Image
            source={{
              uri: 'https://larepublica.cronosmedia.glr.pe/original/2023/04/05/642dbd027a4e234b75501c70.jpg',
            }}
            style={styles.image}
          />
          <Text style={styles.cardTitle}>Fernanda</Text>
          <Text style={styles.cardText}>Whats</Text>
           <TouchableOpacity onPress={tel3}>
                <Image
                    source={{
                        uri: 'https://e7.pngegg.com/pngimages/997/984/png-clipart-call-icon-log-o-whatsapp-computer-icons-android-chatbot-user-whats-logo-grass.png',
                    }}
                    style={styles.scrollImage3}/>
            </TouchableOpacity>
            
        </View>

         
      </ScrollView>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen name="Bloqueo" component={HomeScreen} />
        <Tab.Screen name="Inicio" component={FutbolScreen} />
        <Tab.Screen name="Llamada" component={LlamadaScreen} />
        <Tab.Screen name="Calculadora" component={CalculadoraScreen} />
        <Tab.Screen name="Ecuacion" component={Resolverecuacion} />
        <Tab.Screen name="Juego" component={juegoScreen} />
        <Tab.Screen name="chat" component={ChatScreen} />
        <Tab.Screen name="camara" component={CamaraScreen} />
        <Tab.Screen name="Mensaje" component={SendMessageScreen}/>
        
      </Tab.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'black',
        paddingHorizontal: 20,
        paddingVertical: 30,
    },
     background: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    },
    container: {
      alignItems: "center",
      padding: 20,
    },
    time: {
      fontSize: 72,
      color: "white",
      fontWeight: "bold",
    },
    date: {
      fontSize: 20,
      color: "white",
      marginBottom: 40,
    },
    
    instruction: {
      fontSize: 16,
      color: "white",
      marginTop: 20,
      textAlign: "center",
    },
  contenedor: {
      flex: 1,
      backgroundColor: '#212f3c',
      padding: 20,
      justifyContent: 'flex-start',
      alignItems: 'flex-start',
    },
    
    baseText: {
      fontFamily: 'arial'
    },
    titleText: {
      fontFamily: 'Arial',
      fontSize: 35,
      fontWeight: 'bold',
      color: 'white',
      textAlign: 'left'
    },
    titleText2: {
      fontFamily: 'arial',
      fontSize: 10,
      fontWeight: 'bold',
      color: 'white',
      textAlign: 'left'
    },


    row: {
      flexDirection: 'row',
      justifyContent: 'space-evenly',
      width: '100%',
      marginBottom: 5,
    },
    Contenedor1: {
      backgroundColor: 'white',
      flex: 1,
      height: 50,
      width: 50,
      justifyContent: 'center',
      alignItems: 'center',
      marginLeft: 10,
      marginRight: 10,
      borderRadius: 10,
      overflow: 'hidden',
      margin: 18
    },
    Contenedor2: {
      backgroundColor: 'white',
      flex: 1,
      height: 50,
      width: 50,
      justifyContent: 'center',
      alignItems: 'center',
      marginLeft: 10,
      marginRight: 10,
      borderRadius: 10,
      overflow: 'hidden',
      margin: 18
    },
    Contenedor3: {
      backgroundColor: 'white',
      flex: 1,
      height: 50,
      width: 50,
      justifyContent: 'center',
      alignItems: 'center',
      marginLeft: 10,
      marginRight: 10,
      borderRadius: 10,
      overflow: 'hidden',
      margin: 18
    },
      Contenedor4: {
      backgroundColor: '#424949',
      flex: 1,
      height: 50,
      width: 50,
      justifyContent: 'center',
      alignItems: 'center',
      marginLeft: 10,
      marginRight: 10,
      borderRadius: 10,
      overflow: 'hidden',
      margin: 18,
    },
    scrollImage: {
          width: 100,
          height: 150,
          borderRadius: 10,
          marginTop: 10,
      },
    scrollImage2: {
          width: 50,
          height: 60,
          borderRadius: 10,
          marginTop: 4,
      },
      scrollImage3: {
          width: 50,
          height: 45,
          borderRadius: 20,
          marginTop: 10,
          marginLeft: 95
      },
       scrollImage4: {
          width: 50,
          height: 50,
         
          resizeMode: 'cover',
      },
    
  outerContainer: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },

  scrollView: {
    flex: 1,
    paddingHorizontal: 10,
  },
  scrollContent: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  cardContainer: {
    backgroundColor: '#fff',
    marginBottom: 20,
    padding: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    width: '90%',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  cardText: {
    fontSize: 14,
    marginBottom: 15,
  },
  image: {
    width: 245,
    height: 100,
    resizeMode: 'contain',
    marginBottom: 10,
    borderRadius: 50,

  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
    height: 60,
    borderTopWidth: 1,
    borderColor: '#ddd',
  },
  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    width: 30,
    height: 30,
    marginRight: 5, 
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 5,
  },
  contenedorGeneral: {
    flex: 1,
    backgroundColor: '#1d0508',
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  entradaTexto: {
    height: 50,
    margin: 5,
    borderColor: 'white',
    borderWidth: 2,
    padding: 1,
    width: 320,
    marginBottom: 10,
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
  },
  fila: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 5,
  },
  botonContenedor: {
    backgroundColor: '#424949',
    flex: 1,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 2,
  },
  botonIgualContenedor: {
    backgroundColor: '#900cc2',
    flex: 1,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 2,
  },



  container8: {
    flex: 1,
    backgroundColor: '#4f6e7c',
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginVertical: 15,
  },
  titlefutbol: {
    fontSize: 28,
    fontWeight: '900',
    color: '#f5f5f5',
    textAlign: 'center',
    marginVertical: 20,
  },
  headerImage2: {
    width: '100%',
    height: 200,
    marginBottom: 25,
    borderRadius: 10,
  },

  itemContainer: {
    marginRight: 20,
    alignItems: 'center',
  },
  scrollImage: {
    width: 150,
    height: 150,
    marginTop: 10,
    borderRadius: 10,
  },

  input1: {
    backgroundColor: '',
    height: 20,
    margin: 5,
    borderColor: 'white',
    borderWidth: 2,
    padding: 2,
    width: 50,
    marginBottom: 20,
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
   container2: {
    flex: 5,
    justifyContent: 'center', 
    alignItems: 'center', 
   },
   container5: {
    flex: 1,
    backgroundColor: '#743e6e',
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  title14: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginVertical: 15,
  },

  
   mainContainer: {
    flex: 1,
    backgroundColor: '#f1f1f1',
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#238b5c', 
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  profileImage: {
    width: 70,
    height: 70,
    borderRadius: 50, 
    marginRight: 10,
  },
  headerText: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold',
  },
  messageBox: {
    marginVertical: 10,
    padding: 12,
    borderRadius: 20,
    maxWidth: '80%',
  },
  userMessage: {
    backgroundColor: '#DCF8C6', 
    alignSelf: 'flex-end',
  },
  friendMessage: {
    backgroundColor: '#FFFFFF', 
    alignSelf: 'flex-start',
    borderColor: '#E0E0E0',
    borderWidth: 1,
  },
  messageSender: {
    fontWeight: 'bold',
    color: '#075E54', 
  },
  messageContent: {
    fontSize: 16,
    color: '#333',
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    backgroundColor: '#fff',
  },
  inputField: {
    flex: 1,
    padding: 10,
    backgroundColor: '#F0F0F0',
    borderRadius: 30,
    marginRight: 10,
  },
  sendButtonImage: {
    width: 40,
    height: 40,
    resizeMode: 'contain',
  },


});


